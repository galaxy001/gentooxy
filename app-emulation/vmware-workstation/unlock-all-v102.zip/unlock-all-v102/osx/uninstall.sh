#!/bin/sh
set -e

echo VMware Unlocker 1.0.1
echo =====================
echo Copyright: Dave Parsons 2011

# Ensure we only use unmodified commands
export PATH=/bin:/sbin:/usr/bin:/usr/sbin

echo Patching...
./Unlocker.OSX -u

echo Finished!

