#!/bin/sh
set -e

echo VMware ESXi 5.0 Unlocker 1.0.1
echo ==============================

# Ensure we only use unmodified commands
export PATH=/bin:/sbin:/usr/bin:/usr/sbin

# Remove entry from the boot configuration file
echo Deleting darwin.tgz from boot.cfg...
BootModuleConfig.sh --remove=darwin.tgz --verbose

# Clean up
rm -f darwin.tgz
rm -rf ./bin

echo Please now reboot the host system!
